/* global ClanLogic, ClanGames */
(function () {
  const L = window.ClanLogic;
  const G = window.ClanGames;
  const PROFILE_KEY = "clanboard.v2.profile";
  const CLANS_KEY = "clanboard.v2.clans";
  const PARTIES_KEY = "clanboard.v2.parties";
  const $ = (id) => document.getElementById(id);

  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      return fallback;
    }
  }
  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }
  function loadProfile() {
    return readJson(PROFILE_KEY, null);
  }
  function loadClans() {
    const rows = readJson(CLANS_KEY, null);
    if (!rows || !rows.length) {
      const seeded = L.seedClans();
      writeJson(CLANS_KEY, seeded);
      return seeded;
    }
    return rows;
  }
  function loadParties() {
    const rows = readJson(PARTIES_KEY, null);
    if (!rows || !rows.length) {
      const seeded = L.seedParties();
      writeJson(PARTIES_KEY, seeded);
      return seeded;
    }
    return rows;
  }
  function replaceById(rows, next) {
    return rows.map((r) => (r.id === next.id ? next : r));
  }
  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }
  function setMsg(id, text, isError) {
    const el = $(id);
    el.hidden = !text;
    el.textContent = text || "";
    el.className = "msg" + (isError ? " err" : " ok");
  }
  function fillSelect(el, items) {
    el.innerHTML = items
      .map((v) => {
        const id = typeof v === "object" ? v.id : v;
        const label = typeof v === "object" ? v.name || v.label : v;
        return `<option value="${escapeHtml(id)}">${escapeHtml(label)}</option>`;
      })
      .join("");
  }
  function fillFilter(el, items) {
    el.innerHTML =
      '<option value="">Any</option>' +
      items
        .map((v) => {
          const id = typeof v === "object" ? v.id : v;
          const label = typeof v === "object" ? v.name || v.label : v;
          return `<option value="${escapeHtml(id)}">${escapeHtml(label)}</option>`;
        })
        .join("");
  }
  function gameName(id) {
    const g = G.getGame(id);
    return g ? g.name : id;
  }
  function currentTab() {
    const h = (location.hash || "#join").replace("#", "");
    return h === "create" || h === "party" ? h : "join";
  }
  function showTab(name) {
    $("joinPane").hidden = name !== "join";
    $("createPane").hidden = name !== "create";
    $("partyPane").hidden = name !== "party";
    $("tabJoin").classList.toggle("on", name === "join");
    $("tabCreate").classList.toggle("on", name === "create");
    $("tabParty").classList.toggle("on", name === "party");
    if (location.hash !== "#" + name) location.hash = name;
  }
  function syncCreateExtras() {
    const game = G.getGame($("cGame").value);
    const box = $("cExtras");
    if (!game || !game.extra.length) {
      box.innerHTML = "";
      return;
    }
    box.innerHTML = game.extra
      .map((field) => {
        const opts = field.options
          .map((o) => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`)
          .join("");
        return `<div><label>${escapeHtml(field.label)}</label>
          <select id="ex_${escapeHtml(field.key)}">${opts}</select></div>`;
      })
      .join("");
  }
  function syncPartyModes(selectId, gameId, withAny) {
    const game = G.getGame(gameId);
    const el = $(selectId);
    if (!game) {
      el.innerHTML = withAny ? '<option value="">Any mode</option>' : "";
      return;
    }
    const body = game.parties
      .map(
        (p) =>
          `<option value="${escapeHtml(p.id)}">${escapeHtml(p.label)} (${p.size})</option>`,
      )
      .join("");
    el.innerHTML = (withAny ? '<option value="">Any mode</option>' : "") + body;
  }
  function extraPayload() {
    const game = G.getGame($("cGame").value);
    const extras = {};
    (game.extra || []).forEach((field) => {
      const el = $("ex_" + field.key);
      extras[field.key] = el ? el.value : "";
    });
    return extras;
  }
  function paintProfile() {
    const p = loadProfile();
    if (!p) {
      $("profileStatus").textContent = "Save a profile or Join / Party stay locked.";
      return;
    }
    $("pName").value = p.name;
    $("pPlatform").value = p.platform;
    $("pRegion").value = p.region;
    $("pLang").value = p.lang;
    $("profileStatus").textContent =
      p.name + " · " + p.platform + " · " + p.region;
  }
  function paintJoin() {
    const profile = loadProfile();
    const ranked = L.sortForJoin(
      L.filterClans(loadClans(), {
        gameId: $("fGame").value,
        platform: $("fPlatform").value,
        region: $("fRegion").value,
        lang: $("fLang").value,
        status: $("fStatus").value,
      }),
      profile,
    );
    const box = $("joinList");
    if (!ranked.length) {
      box.innerHTML = '<p class="empty">No listings match.</p>';
      return;
    }
    box.innerHTML = ranked
      .map(({ clan, fit }) => {
        const game = G.getGame(clan.gameId);
        const extraBits = Object.values(clan.extras || {}).filter(Boolean).join(" · ");
        const gate = L.canJoin(clan, profile);
        let action = "<span class='meta'>Save profile to join</span>";
        if (profile && !gate.ok) {
          action = `<span class="stale">${escapeHtml(gate.error)}</span>`;
        } else if (profile && clan.status === "open") {
          action = `<button class="btn" data-join="${escapeHtml(clan.id)}">Join Discord</button>`;
        } else if (profile) {
          action = `<button class="btn" data-join="${escapeHtml(clan.id)}">Apply</button>`;
        }
        return `<article>
          <div class="head"><h2>${escapeHtml(clan.name)}</h2>
            <span class="score">${fit.hardFail ? "no-fit" : fit.score + "% fit"}</span></div>
          <p class="meta">${escapeHtml(gameName(clan.gameId))} ${escapeHtml(game.org)} ·
            ${escapeHtml(clan.platform)} · cap ${escapeHtml(String(clan.cap))}
            ${extraBits ? " · " + escapeHtml(extraBits) : ""}</p>
          <div class="tags">
            <span class="${clan.status === "open" ? "open" : ""}">${escapeHtml(clan.status)}</span>
            <span>${escapeHtml(clan.region)}</span>
            <span>${escapeHtml(String(clan.members))}/${escapeHtml(String(clan.cap))}</span>
          </div>
          <p>${escapeHtml(clan.blurb || "")}</p>
          <div class="row">${action}</div>
        </article>`;
      })
      .join("");
  }
  function paintMine() {
    const profile = loadProfile();
    const box = $("mineList");
    if (!profile) {
      box.innerHTML = "<p class='empty'>Save a profile on Join first.</p>";
      return;
    }
    const mine = loadClans().filter((c) => c.ownerName === profile.name);
    if (!mine.length) {
      box.innerHTML = "<p class='empty'>You have not created a listing.</p>";
      return;
    }
    box.innerHTML = mine
      .map((clan) => {
        const pending = (clan.applications || []).filter((a) => a.state === "pending");
        const apps = pending.length
          ? pending
              .map(
                (a) => `<div class="row app">
              <span>${escapeHtml(a.name)} · ${escapeHtml(a.platform)}</span>
              <button class="btn" data-accept="${escapeHtml(clan.id)}" data-who="${escapeHtml(a.name)}">Accept</button>
              <button class="ghost" data-deny="${escapeHtml(clan.id)}" data-who="${escapeHtml(a.name)}">Deny</button>
            </div>`,
              )
              .join("")
          : "<p class='meta'>No pending applications.</p>";
        return `<article>
          <h2>${escapeHtml(clan.name)}</h2>
          <p class="meta">${escapeHtml(gameName(clan.gameId))} · ${escapeHtml(clan.status)}</p>
          <button class="ghost" data-bump="${escapeHtml(clan.id)}">Bump</button>
          ${apps}
        </article>`;
      })
      .join("");
  }
  function paintParties() {
    const profile = loadProfile();
    const rows = L.filterParties(loadParties(), {
      gameId: $("yGame").value,
      modeId: $("yMode").value,
      platform: $("yPlatform").value,
      region: $("yRegion").value,
      openOnly: $("yOpen").checked,
    }).sort((a, b) => b.createdAt - a.createdAt);
    const box = $("partyList");
    if (!rows.length) {
      box.innerHTML = "<p class='empty'>No parties match.</p>";
      return;
    }
    box.innerHTML = rows
      .map((p) => {
        const left = p.size - p.members.length;
        let action = "<span class='meta'>Save profile to join</span>";
        if (profile && left <= 0) action = "<span class='stale'>Full</span>";
        else if (profile && p.members.includes(profile.name)) {
          action = "<span class='meta'>You're in</span>";
        } else if (profile) {
          action = `<button class="btn" data-pjoin="${escapeHtml(p.id)}">Join · ${left} left</button>`;
        }
        return `<article>
          <div class="head"><h2>${escapeHtml(p.title)}</h2>
            <span class="score">${escapeHtml(String(p.members.length))}/${escapeHtml(String(p.size))}</span></div>
          <p class="meta">${escapeHtml(gameName(p.gameId))} · ${escapeHtml(p.modeLabel)} ·
            ${escapeHtml(p.platform)} · ${escapeHtml(p.starts || "now")}</p>
          <p>${escapeHtml(p.blurb || "")}</p>
          <p class="meta">In: ${escapeHtml(p.members.join(", "))}</p>
          <div class="row">${action}</div>
        </article>`;
      })
      .join("");
  }
  function paint() {
    paintProfile();
    paintJoin();
    paintMine();
    paintParties();
  }
  function bind() {
    fillSelect($("pPlatform"), L.PLATFORMS);
    fillSelect($("pRegion"), L.REGIONS);
    fillSelect($("pLang"), L.LANGS);
    fillFilter($("fGame"), G.GAMES);
    fillFilter($("fPlatform"), L.PLATFORMS);
    fillFilter($("fRegion"), L.REGIONS);
    fillFilter($("fLang"), L.LANGS);
    fillSelect($("cGame"), G.GAMES);
    fillSelect($("cPlatform"), L.PLATFORMS);
    fillSelect($("cRegion"), L.REGIONS);
    fillSelect($("cLang"), L.LANGS);
    fillSelect($("xGame"), G.GAMES);
    fillSelect($("xPlatform"), L.PLATFORMS);
    fillSelect($("xRegion"), L.REGIONS);
    fillSelect($("xLang"), L.LANGS);
    fillFilter($("yGame"), G.GAMES);
    fillFilter($("yPlatform"), L.PLATFORMS);
    fillFilter($("yRegion"), L.REGIONS);
    syncCreateExtras();
    syncPartyModes("xMode", $("xGame").value, false);
    syncPartyModes("yMode", G.GAMES[0].id, true);

    $("tabJoin").onclick = () => showTab("join");
    $("tabCreate").onclick = () => showTab("create");
    $("tabParty").onclick = () => showTab("party");
    window.addEventListener("hashchange", () => showTab(currentTab()));
    $("cGame").addEventListener("change", syncCreateExtras);
    $("xGame").addEventListener("change", () =>
      syncPartyModes("xMode", $("xGame").value, false),
    );
    $("yGame").addEventListener("change", () => {
      syncPartyModes("yMode", $("yGame").value || G.GAMES[0].id, true);
      paintParties();
    });

    $("profileForm").addEventListener("submit", (ev) => {
      ev.preventDefault();
      const res = L.validateProfile({
        name: $("pName").value,
        platform: $("pPlatform").value,
        region: $("pRegion").value,
        lang: $("pLang").value,
      });
      if (!res.ok) {
        setMsg("profileMsg", res.errors.join(". "), true);
        return;
      }
      writeJson(PROFILE_KEY, res.profile);
      setMsg("profileMsg", "Profile saved.", false);
      paint();
    });

    $("createForm").addEventListener("submit", (ev) => {
      ev.preventDefault();
      const profile = loadProfile();
      if (!profile) {
        setMsg("createMsg", "Save a profile on Join first.", true);
        return;
      }
      const extras = extraPayload();
      const res = L.validateClan({
        gameId: $("cGame").value,
        name: $("cName").value,
        platform: $("cPlatform").value,
        region: $("cRegion").value,
        lang: $("cLang").value,
        rank: $("cRank").value,
        when: $("cWhen").value,
        blurb: $("cBlurb").value,
        status: $("cStatus").value,
        invite: $("cInvite").value,
        req: $("cReq").value,
        size: "1",
        ownerName: profile.name,
        extras,
        ...extras,
        membersList: [
          { name: profile.name, platform: profile.platform, joinedAt: Date.now() },
        ],
      });
      if (!res.ok) {
        setMsg("createMsg", res.errors.join(". "), true);
        return;
      }
      writeJson(CLANS_KEY, [res.clan].concat(loadClans()));
      setMsg("createMsg", res.clan.name + " published.", false);
      paint();
      showTab("join");
    });

    $("partyForm").addEventListener("submit", (ev) => {
      ev.preventDefault();
      const profile = loadProfile();
      if (!profile) {
        setMsg("partyMsg", "Save a profile on Join first.", true);
        return;
      }
      const res = L.validateParty({
        gameId: $("xGame").value,
        modeId: $("xMode").value,
        title: $("xTitle").value,
        platform: $("xPlatform").value,
        region: $("xRegion").value,
        lang: $("xLang").value,
        blurb: $("xBlurb").value,
        invite: $("xInvite").value,
        starts: $("xStarts").value,
        hostName: profile.name,
      });
      if (!res.ok) {
        setMsg("partyMsg", res.errors.join(". "), true);
        return;
      }
      writeJson(PARTIES_KEY, [res.party].concat(loadParties()));
      setMsg("partyMsg", "Party posted (" + res.party.size + " slots).", false);
      paintParties();
    });

    ["fGame", "fPlatform", "fRegion", "fLang", "fStatus"].forEach((id) => {
      $(id).addEventListener("change", paintJoin);
    });
    ["yMode", "yPlatform", "yRegion", "yOpen"].forEach((id) => {
      $(id).addEventListener("change", paintParties);
    });

    $("joinList").addEventListener("click", (ev) => {
      const btn = ev.target.closest("[data-join]");
      if (!btn) return;
      const rows = loadClans();
      const clan = rows.find((c) => c.id === btn.getAttribute("data-join"));
      const res = L.applyJoin(clan, loadProfile());
      if (!res.ok) {
        setMsg("joinMsg", res.error, true);
        paint();
        return;
      }
      writeJson(CLANS_KEY, replaceById(rows, res.clan));
      if (res.mode === "joined") window.open(res.invite, "_blank", "noopener");
      setMsg("joinMsg", res.mode === "joined" ? "Joined. Opening Discord." : "Application sent.", false);
      paint();
    });

    $("mineList").addEventListener("click", (ev) => {
      const acc = ev.target.closest("[data-accept]");
      const den = ev.target.closest("[data-deny]");
      const bump = ev.target.closest("[data-bump]");
      const rows = loadClans();
      if (acc || den) {
        const el = acc || den;
        const clan = rows.find((c) => c.id === el.getAttribute(acc ? "data-accept" : "data-deny"));
        const res = L.decideApplication(clan, el.getAttribute("data-who"), Boolean(acc));
        if (!res.ok) {
          setMsg("createMsg", res.error, true);
          return;
        }
        writeJson(CLANS_KEY, replaceById(rows, res.clan));
        paint();
      }
      if (bump) {
        const clan = rows.find((c) => c.id === bump.getAttribute("data-bump"));
        clan.bumped = Date.now();
        writeJson(CLANS_KEY, replaceById(rows, clan));
        paint();
      }
    });

    $("partyList").addEventListener("click", (ev) => {
      const btn = ev.target.closest("[data-pjoin]");
      if (!btn) return;
      const rows = loadParties();
      const party = rows.find((p) => p.id === btn.getAttribute("data-pjoin"));
      const res = L.joinParty(party, loadProfile());
      if (!res.ok) {
        setMsg("partyMsg", res.error, true);
        paintParties();
        return;
      }
      writeJson(PARTIES_KEY, replaceById(rows, res.party));
      window.open(res.invite, "_blank", "noopener");
      setMsg("partyMsg", res.full ? "Party full. Opening Discord." : "You're in.", false);
      paintParties();
    });

    $("resetData").onclick = () => {
      localStorage.removeItem(CLANS_KEY);
      localStorage.removeItem(PARTIES_KEY);
      paint();
    };

    showTab(currentTab());
    paint();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
