const assert = require("assert");
const S = require("./social.js");

assert.strictEqual(S.dmChannel("Omar", "Ali"), "dm:ali:omar");
assert.strictEqual(S.dmChannel("Ali", "Omar"), "dm:ali:omar");
assert.ok(!S.parseChannel("nope"));
assert.deepStrictEqual(S.parseChannel("clan:c_1"), { type: "clan", id: "c_1" });

let friends = [];
let r = S.requestFriend(friends, "Omar", "Omar");
assert.strictEqual(r.ok, false);
r = S.requestFriend(friends, "Omar", "Ali");
assert.strictEqual(r.mode, "pending");
friends = r.friends;
r = S.requestFriend(friends, "Omar", "Ali");
assert.strictEqual(r.ok, false);
r = S.requestFriend(friends, "Ali", "Omar");
assert.strictEqual(r.mode, "accepted");
assert.ok(S.areFriends(friends, "omar", "ALI"));

friends = [];
friends = S.requestFriend(friends, "A", "B").friends;
r = S.decideFriend(friends, "A", "B", true);
assert.strictEqual(r.ok, false);
r = S.decideFriend(friends, "B", "A", true);
assert.strictEqual(r.mode, "accepted");

const list = S.friendList(friends, "A");
assert.deepStrictEqual(list.accepted, ["b"]);

assert.ok(
  S.canAccessChannel({
    name: "Omar",
    friends,
    channel: S.dmChannel("A", "B"),
    clans: [],
    parties: [],
  }) === false,
);
assert.ok(
  S.canAccessChannel({
    name: "A",
    friends,
    channel: S.dmChannel("A", "B"),
    clans: [],
    parties: [],
  }),
);
assert.ok(
  S.canAccessChannel({
    name: "Omar",
    friends: [],
    channel: "clan:c1",
    clans: [{ id: "c1", ownerName: "Omar", membersList: [] }],
    parties: [],
  }),
);
assert.ok(
  !S.canAccessChannel({
    name: "X",
    friends: [],
    channel: "party:p1",
    clans: [],
    parties: [{ id: "p1", members: ["Omar"] }],
  }),
);

const posted = S.postMessage([], { channel: "dm:a:b", from: "A", text: "hi" });
assert.strictEqual(posted.ok, true);
assert.strictEqual(S.postMessage([], { channel: "x", from: "A", text: "" }).ok, false);

console.log("ok social");
