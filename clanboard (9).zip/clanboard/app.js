/* global ClanLogic */
(function () {
  const L = window.ClanLogic;
  const PROFILE_KEY = "clanboard.wf.profile";
  const CLANS_KEY = "clanboard.wf.clans";

  const $ = (id) => document.getElementById(id);

  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      return JSON.parse(raw);
    } catch (err) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function loadProfile() {
    return readJson(PROFILE_KEY, null);
  }

  function saveProfile(profile) {
    writeJson(PROFILE_KEY, profile);
  }

  function loadClans() {
    const rows = readJson(CLANS_KEY, null);
    if (!rows || !rows.length) {
      const seeded = L.seedClans();
      writeJson(CLANS_KEY, seeded);
      return seeded;
    }
    return rows;
  }

  function saveClans(rows) {
    writeJson(CLANS_KEY, rows);
  }

  function replaceClan(rows, next) {
    return rows.map((c) => (c.id === next.id ? next : c));
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  function setMsg(id, text, isError) {
    const el = $(id);
    el.hidden = !text;
    el.textContent = text || "";
    el.className = "msg" + (isError ? " err" : " ok");
  }

  function fillSelect(el, items, selected) {
    el.innerHTML = items
      .map((v) => {
        const sel = v === selected ? " selected" : "";
        return `<option value="${escapeHtml(v)}"${sel}>${escapeHtml(v)}</option>`;
      })
      .join("");
  }

  function fillFilter(el, items, selected) {
    const opts = [""].concat(items);
    el.innerHTML = opts
      .map((v) => {
        const label = v || "Any";
        const sel = v === selected ? " selected" : "";
        return `<option value="${escapeHtml(v)}"${sel}>${escapeHtml(label)}</option>`;
      })
      .join("");
  }

  function currentTab() {
    const h = (location.hash || "#join").replace("#", "");
    return h === "create" ? "create" : "join";
  }

  function showTab(name) {
    $("joinPane").hidden = name !== "join";
    $("createPane").hidden = name !== "create";
    $("tabJoin").classList.toggle("on", name === "join");
    $("tabCreate").classList.toggle("on", name === "create");
    if (location.hash !== "#" + name) {
      location.hash = name;
    }
  }

  function paintProfile() {
    const p = loadProfile();
    if (!p) {
      $("profileStatus").textContent = "No profile — join is locked until you save one.";
      return;
    }
    $("pName").value = p.name;
    $("pPlatform").value = p.platform;
    $("pRegion").value = p.region;
    $("pLang").value = p.lang;
    $("pMr").value = String(p.mr);
    $("profileStatus").textContent =
      p.name + " · " + p.platform + " · MR " + p.mr + " · " + p.region;
  }

  function paintJoin() {
    const profile = loadProfile();
    const filters = {
      platform: $("fPlatform").value,
      region: $("fRegion").value,
      lang: $("fLang").value,
      tier: $("fTier").value,
      status: $("fStatus").value,
    };
    const filtered = L.filterClans(loadClans(), filters);
    const ranked = L.sortForJoin(filtered, profile);
    const box = $("joinList");
    if (!ranked.length) {
      box.innerHTML = '<p class="empty">No clans match those filters.</p>';
      return;
    }
    box.innerHTML = ranked
      .map(({ clan, fit }) => {
        const age = L.daysOld(clan.bumped);
        const stale = L.isStale(clan)
          ? `<span class="stale">stale ${age}d</span>`
          : `<span class="meta">bumped ${age === 0 ? "today" : age + "d ago"}</span>`;
        const gate = L.canJoin(clan, profile);
        let action = "";
        if (!profile) {
          action = "<span class='meta'>Save profile to join</span>";
        } else if (!gate.ok) {
          action = `<span class="stale">${escapeHtml(gate.error)}</span>`;
        } else if (clan.status === "open") {
          action = `<button class="btn" data-join="${escapeHtml(clan.id)}">Join Discord</button>`;
        } else {
          action = `<button class="btn" data-join="${escapeHtml(clan.id)}">Apply</button>`;
        }
        return `<article>
          <div class="head">
            <h2>${escapeHtml(clan.name)}</h2>
            <span class="score">${fit.hardFail ? "no-fit" : fit.score + "% fit"}</span>
          </div>
          <p class="meta">${escapeHtml(clan.platform)} · ${escapeHtml(clan.tier)} ·
            MR ${escapeHtml(clan.mr)}+ · ${escapeHtml(clan.region)} · ${escapeHtml(clan.lang)}</p>
          <div class="tags">
            <span class="${clan.status === "open" ? "open" : ""}">${escapeHtml(clan.status)}</span>
            <span>${escapeHtml(clan.rank || "no focus")}</span>
            <span>${escapeHtml(String(clan.members))}/${escapeHtml(String(clan.cap))} Tenno</span>
            <span>${escapeHtml(clan.when || "hours n/a")}</span>
          </div>
          <p>${escapeHtml(clan.blurb || "")}</p>
          <p class="meta">${escapeHtml((fit.reasons || []).join(" · "))}</p>
          <div class="row">${action} ${stale}</div>
        </article>`;
      })
      .join("");
  }

  function paintMine() {
    const profile = loadProfile();
    const clans = loadClans();
    const mine = profile
      ? clans.filter((c) => c.ownerName === profile.name)
      : [];
    const box = $("mineList");
    if (!profile) {
      box.innerHTML = '<p class="empty">Save a Join-tab profile so Create knows who you are.</p>';
      return;
    }
    if (!mine.length) {
      box.innerHTML = '<p class="empty">You have not created a clan yet.</p>';
      return;
    }
    box.innerHTML = mine
      .map((clan) => {
        const pending = (clan.applications || []).filter((a) => a.state === "pending");
        const apps = pending.length
          ? pending
              .map(
                (a) => `<div class="row app">
              <span>${escapeHtml(a.name)} · ${escapeHtml(a.platform)} · MR ${escapeHtml(a.mr)}</span>
              <button class="btn" data-accept="${escapeHtml(clan.id)}" data-who="${escapeHtml(a.name)}">Accept</button>
              <button class="ghost" data-deny="${escapeHtml(clan.id)}" data-who="${escapeHtml(a.name)}">Deny</button>
            </div>`,
              )
              .join("")
          : "<p class='meta'>No pending applications.</p>";
        return `<article>
          <h2>${escapeHtml(clan.name)}</h2>
          <p class="meta">${escapeHtml(clan.status)} · ${escapeHtml(String(clan.members))}/${escapeHtml(String(clan.cap))} · ${escapeHtml(clan.tier)}</p>
          <div class="row">
            <button class="ghost" data-bump="${escapeHtml(clan.id)}">Bump listing</button>
          </div>
          ${apps}
        </article>`;
      })
      .join("");
  }

  function paint() {
    paintProfile();
    paintJoin();
    paintMine();
  }

  function onSaveProfile(ev) {
    ev.preventDefault();
    const res = L.validateProfile({
      name: $("pName").value,
      platform: $("pPlatform").value,
      region: $("pRegion").value,
      lang: $("pLang").value,
      mr: $("pMr").value,
    });
    if (!res.ok) {
      setMsg("profileMsg", res.errors.join(". "), true);
      return;
    }
    saveProfile(res.profile);
    setMsg("profileMsg", "Profile saved. Join buttons use this Tenno.", false);
    paint();
  }

  function onCreate(ev) {
    ev.preventDefault();
    const profile = loadProfile();
    if (!profile) {
      setMsg("createMsg", "Save your Tenno profile on the Join tab first.", true);
      return;
    }
    const res = L.validateClan({
      name: $("cName").value,
      platform: $("cPlatform").value,
      tier: $("cTier").value,
      mr: $("cMr").value,
      region: $("cRegion").value,
      lang: $("cLang").value,
      rank: $("cRank").value,
      when: $("cWhen").value,
      blurb: $("cBlurb").value,
      status: $("cStatus").value,
      invite: $("cInvite").value,
      size: "1",
      ownerName: profile.name,
      membersList: [
        {
          name: profile.name,
          platform: profile.platform,
          mr: profile.mr,
          joinedAt: Date.now(),
        },
      ],
    });
    if (!res.ok) {
      setMsg("createMsg", res.errors.join(". "), true);
      return;
    }
    const rows = loadClans();
    if (rows.some((c) => c.name.toLowerCase() === res.clan.name.toLowerCase()
      && c.platform === res.clan.platform)) {
      setMsg("createMsg", "That clan name already exists on this platform.", true);
      return;
    }
    saveClans([res.clan].concat(rows));
    $("createForm").reset();
    setMsg("createMsg", res.clan.name + " is live on the Join tab.", false);
    paint();
    showTab("join");
  }

  function onJoinClick(id) {
    const profile = loadProfile();
    const rows = loadClans();
    const clan = rows.find((c) => c.id === id);
    if (!clan) {
      setMsg("joinMsg", "Clan no longer exists.", true);
      return;
    }
    const res = L.applyJoin(clan, profile);
    if (!res.ok) {
      setMsg("joinMsg", res.error, true);
      paint();
      return;
    }
    saveClans(replaceClan(rows, res.clan));
    if (res.mode === "joined") {
      setMsg("joinMsg", "Joined " + clan.name + ". Opening Discord invite.", false);
      window.open(res.invite, "_blank", "noopener");
    } else {
      setMsg("joinMsg", "Application sent to " + clan.name + ". Wait for accept.", false);
    }
    paint();
  }

  function onDecide(id, who, accept) {
    const rows = loadClans();
    const clan = rows.find((c) => c.id === id);
    if (!clan) return;
    const res = L.decideApplication(clan, who, accept);
    if (!res.ok) {
      setMsg("createMsg", res.error, true);
      return;
    }
    saveClans(replaceClan(rows, res.clan));
    setMsg("createMsg", (accept ? "Accepted " : "Denied ") + who + ".", false);
    paint();
  }

  function onBump(id) {
    const rows = loadClans();
    const clan = rows.find((c) => c.id === id);
    if (!clan) return;
    clan.bumped = Date.now();
    saveClans(replaceClan(rows, clan));
    setMsg("createMsg", "Bumped " + clan.name + ".", false);
    paint();
  }

  function bind() {
    fillSelect($("pPlatform"), L.PLATFORMS);
    fillSelect($("pRegion"), L.REGIONS);
    fillSelect($("pLang"), L.LANGS);
    fillSelect($("cPlatform"), L.PLATFORMS);
    fillSelect($("cRegion"), L.REGIONS);
    fillSelect($("cLang"), L.LANGS);
    fillSelect($("cTier"), L.TIERS);
    fillFilter($("fPlatform"), L.PLATFORMS);
    fillFilter($("fRegion"), L.REGIONS);
    fillFilter($("fLang"), L.LANGS);
    fillFilter($("fTier"), L.TIERS);

    $("tabJoin").addEventListener("click", () => showTab("join"));
    $("tabCreate").addEventListener("click", () => showTab("create"));
    window.addEventListener("hashchange", () => showTab(currentTab()));

    $("profileForm").addEventListener("submit", onSaveProfile);
    $("createForm").addEventListener("submit", onCreate);

    ["fPlatform", "fRegion", "fLang", "fTier", "fStatus"].forEach((id) => {
      $(id).addEventListener("change", paintJoin);
    });

    $("joinList").addEventListener("click", (ev) => {
      const btn = ev.target.closest("[data-join]");
      if (btn) onJoinClick(btn.getAttribute("data-join"));
    });
    $("mineList").addEventListener("click", (ev) => {
      const acc = ev.target.closest("[data-accept]");
      if (acc) {
        onDecide(acc.getAttribute("data-accept"), acc.getAttribute("data-who"), true);
        return;
      }
      const den = ev.target.closest("[data-deny]");
      if (den) {
        onDecide(den.getAttribute("data-deny"), den.getAttribute("data-who"), false);
        return;
      }
      const bump = ev.target.closest("[data-bump]");
      if (bump) onBump(bump.getAttribute("data-bump"));
    });

    $("resetData").addEventListener("click", () => {
      localStorage.removeItem(CLANS_KEY);
      paint();
      setMsg("joinMsg", "Listings reset to sample clans.", false);
    });

    showTab(currentTab());
    paint();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
