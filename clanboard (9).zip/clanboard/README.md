# Keld

Group finder with friends and chat. Not Discord. Not Steam. Same shape: top tabs, left list, a board in the middle.

## Run locally

    node server.js

Open http://localhost:3847
Create an account. There are no sample clans.

## Deploy (Render, free)

Repo must contain server.js and package.json at the root (or set Root Directory).

- Runtime: Node
- Build: npm install
- Start: node server.js
- Instance: Free

Open the onrender.com URL only. Friends use that same URL.

Free Render sleeps after idle. First load can be slow. data.json lives on that instance; a new deploy can reset listings unless you add a disk later.

## What syncs

Accounts, clans, parties, applications, friends, DMs, clan chat, party chat.

Chat only works for people who are friends (DMs) or members of that clan/party.
