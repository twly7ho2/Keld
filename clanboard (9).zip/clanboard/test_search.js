const assert = require("assert");
const G = require("./games.js");
const S = require("./search.js");
const L = require("./logic.js");

assert.strictEqual(S.searchGames(G.GAMES, "d2")[0].id, "destiny2");
assert.strictEqual(S.searchGames(G.GAMES, "ff14")[0].id, "ffxiv");
assert.strictEqual(S.searchGames(G.GAMES, "wf")[0].id, "warframe");
assert.strictEqual(S.searchGames(G.GAMES, "coc")[0].id, "clashofclans");
assert.ok(S.searchGames(G.GAMES, "zzzz").length === 0);

const pinnedFirst = S.searchGames(G.GAMES, "", { pinned: ["poe"] });
assert.strictEqual(pinnedFirst[0].id, "poe");

const party = L.validateParty({
  gameId: "rocketleague",
  modeId: "threes",
  title: "std",
  platform: "PC",
  region: "EU",
  lang: "English",
  invite: "https://discord.gg/rl",
  hostName: "Host",
}).party;
const joined = L.joinParty(party, {
  name: "Omar",
  platform: "PC",
  region: "EU",
  lang: "English",
}).party;
const left = L.leaveParty(joined, "Omar");
assert.strictEqual(left.ok, true);
assert.strictEqual(left.party.members.includes("Omar"), false);
const gone = L.leaveParty(left.party, "Host");
assert.strictEqual(gone.dissolved, true);

const clan = L.validateClan({
  gameId: "destiny2",
  name: "Desk Clan",
  platform: "PC",
  region: "EU",
  lang: "English",
  status: "apply",
  invite: "https://discord.gg/old",
  ownerName: "Lead",
  membersList: [
    { name: "Lead", platform: "PC", joinedAt: 1 },
    { name: "Omar", platform: "PC", joinedAt: 2 },
  ],
}).clan;
const edited = L.updateClan(clan, { invite: "https://discord.gg/new", status: "open" });
assert.strictEqual(edited.ok, true);
assert.ok(edited.clan.invite.includes("new"));
assert.strictEqual(L.updateClan(clan, { invite: "https://evil.com/x" }).ok, false);
assert.strictEqual(L.kickClanMember(edited.clan, "Omar").ok, true);
assert.strictEqual(L.kickClanMember(edited.clan, "Lead").ok, false);

const pe = L.updateParty(party, { title: "new title", invite: "https://discord.gg/raid2" });
assert.strictEqual(pe.ok, true);
assert.strictEqual(pe.party.title, "new title");

assert.ok(G.getGame("fortnite"));
assert.ok(G.lookupUrl("fortnite", "Ninja").includes("fortnite.gg"));
assert.ok(G.lookupUrl("clashofclans", "#ABC").includes("ABC"));
assert.strictEqual(G.lookupUrl("division2", "x"), null);
assert.strictEqual(S.searchGames(G.GAMES, "fn")[0].id, "fortnite");

const M = require("./membership.js");
assert.strictEqual(M.canLiveCheck("fortnite"), false);
assert.ok(M.whyNoLive("fortnite").includes("no public clan"));
const alb = M.parseAlbion(
  { players: [{ Name: "Omar", GuildName: "Gulf" }] },
  "Omar",
);
assert.strictEqual(alb.inClan, true);
assert.strictEqual(alb.clanName, "Gulf");
assert.strictEqual(M.parseAlbion({ players: [{ Name: "x", GuildName: null }] }, "x").inClan, false);

console.log("ok search");
