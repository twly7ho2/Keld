const assert = require("assert");
const L = require("./logic.js");
const G = require("./games.js");

assert.ok(G.GAMES.length >= 20, "need at least 20 games");
assert.strictEqual(new Set(G.GAMES.map((g) => g.id)).size, G.GAMES.length);

const wf = G.getGame("warframe");
assert.strictEqual(G.orgCap(wf, { tier: "Ghost" }), 10);
assert.strictEqual(G.orgCap(wf, { tier: "Moon" }), 1000);
assert.strictEqual(G.partyMode("warframe", "squad").size, 4);
assert.strictEqual(G.partyMode("destiny2", "raid").size, 6);
assert.strictEqual(G.partyMode("ffxiv", "alliance").size, 24);
assert.strictEqual(G.partyMode("wow", "dungeon").size, 5);
assert.strictEqual(G.partyMode("eso", "trial").size, 12);
assert.strictEqual(G.partyMode("gw2", "squad").size, 50);
assert.strictEqual(G.partyMode("lostark", "guardian").size, 4);
assert.strictEqual(G.partyMode("poe", "maps").size, 6);
assert.strictEqual(G.partyMode("division2", "raid").size, 8);
assert.strictEqual(G.partyMode("clashroyale", "2v2").size, 2);
assert.strictEqual(G.partyMode("brawlstars", "trio").size, 3);
assert.strictEqual(G.partyMode("rocketleague", "threes").size, 3);
assert.strictEqual(G.partyMode("newworld", "expedition").size, 5);

assert.strictEqual(G.partyMode("warframe", "raid"), null);
assert.strictEqual(G.partyMode("destiny2", "squad"), null);

const ghost = L.validateClan({
  gameId: "warframe",
  name: "Tiny Dojo",
  platform: "PC",
  tier: "Ghost",
  region: "EU",
  lang: "English",
  status: "open",
  invite: "https://discord.gg/wf",
  size: "11",
});
assert.strictEqual(ghost.ok, false);

const moon = L.validateClan({
  gameId: "warframe",
  name: "Moon Dojo",
  platform: "PC",
  tier: "Moon",
  region: "EU",
  lang: "English",
  status: "open",
  invite: "https://discord.gg/wf",
  size: "11",
});
assert.strictEqual(moon.ok, true);
assert.strictEqual(moon.clan.cap, 1000);
assert.strictEqual(moon.clan.gameId, "warframe");

const d2 = L.validateClan({
  gameId: "destiny2",
  name: "Tower East",
  platform: "PC",
  region: "EU",
  lang: "English",
  status: "open",
  invite: "https://discord.gg/d2",
  size: "80",
});
assert.strictEqual(d2.ok, true);
assert.strictEqual(d2.clan.cap, 100);

const d2over = L.validateClan({
  gameId: "destiny2",
  name: "Too Big",
  platform: "PC",
  region: "EU",
  lang: "English",
  status: "open",
  invite: "https://discord.gg/d2",
  size: "101",
});
assert.strictEqual(d2over.ok, false);

const fc = L.validateClan({
  gameId: "ffxiv",
  name: "Limsa FC",
  platform: "PC",
  grand: "Maelstrom",
  region: "NA",
  lang: "English",
  status: "open",
  invite: "https://discord.gg/ff",
});
assert.strictEqual(fc.ok, true);
assert.strictEqual(fc.clan.extras.grand, "Maelstrom");
assert.strictEqual(fc.clan.cap, 512);

const profile = {
  name: "Omar",
  platform: "PC",
  region: "Middle East",
  lang: "Arabic",
};

const raid = L.validateParty({
  gameId: "destiny2",
  modeId: "raid",
  title: "SE teaching",
  platform: "PC",
  region: "EU",
  lang: "English",
  invite: "https://discord.gg/d2",
  hostName: "Hawthorne",
});
assert.strictEqual(raid.ok, true);
assert.strictEqual(raid.party.size, 6);

const fakeMode = L.validateParty({
  gameId: "destiny2",
  modeId: "squad",
  title: "nope",
  platform: "PC",
  region: "EU",
  lang: "English",
  invite: "https://discord.gg/d2",
  hostName: "X",
});
assert.strictEqual(fakeMode.ok, false);

let party = raid.party;
for (let i = 0; i < 5; i += 1) {
  const r = L.joinParty(party, { ...profile, name: "P" + i });
  assert.strictEqual(r.ok, true, r.error);
  party = r.party;
}
assert.strictEqual(party.members.length, 6);
assert.strictEqual(L.joinParty(party, { ...profile, name: "P5x" }).ok, false);

const squad = L.validateParty({
  gameId: "warframe",
  modeId: "squad",
  title: "SP",
  platform: "PC",
  region: "EU",
  lang: "English",
  invite: "https://discord.gg/wf",
  hostName: "Host",
}).party;
let wfParty = squad;
for (let i = 0; i < 3; i += 1) {
  wfParty = L.joinParty(wfParty, { ...profile, name: "W" + i }).party;
}
assert.strictEqual(wfParty.members.length, 4);
assert.strictEqual(L.joinParty(wfParty, { ...profile, name: "W9" }).ok, false);

assert.deepStrictEqual(L.seedClans(), []);
assert.deepStrictEqual(L.seedParties(), []);

G.GAMES.forEach((g) => {
  assert.ok(g.parties.length >= 1, g.id + " missing parties");
  g.parties.forEach((p) => {
    assert.ok(p.size >= 1 && p.size <= g.cap, g.id + " " + p.id);
  });
});

console.log("ok games=" + G.GAMES.length);
