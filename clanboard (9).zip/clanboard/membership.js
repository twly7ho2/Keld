/**
 * Clan membership: local board first, then public APIs that actually
 * return a guild field. Most games (Fortnite, Warframe, Destiny) do not.
 */
function localMembership(clans, gameId, boardName) {
  const name = String(boardName || "").trim().toLowerCase();
  if (!name) return [];
  return (clans || []).filter((c) => {
    if (gameId && c.gameId !== gameId) return false;
    if (String(c.ownerName || "").toLowerCase() === name) return true;
    return (c.membersList || []).some((m) => String(m.name || "").toLowerCase() === name);
  });
}

function parseAlbion(data, ign) {
  const want = String(ign || "").toLowerCase();
  const players = (data && data.players) || [];
  const hit = players.find((p) => String(p.Name || "").toLowerCase() === want) || players[0];
  if (!hit) {
    return { found: false, inClan: false, clanName: "", source: "Albion API" };
  }
  const clanName = hit.GuildName || "";
  return {
    found: true,
    player: hit.Name,
    inClan: Boolean(clanName),
    clanName,
    source: "Albion gameinfo API",
  };
}

function parseRobloxUser(data, ign) {
  const want = String(ign || "").toLowerCase();
  const rows = (data && data.data) || [];
  const hit = rows.find((p) => String(p.name || "").toLowerCase() === want) || rows[0];
  if (!hit) return null;
  return { id: hit.id, name: hit.name };
}

function parseRobloxGroups(data) {
  const rows = (data && data.data) || [];
  if (!rows.length) {
    return { found: true, inClan: false, clanName: "", source: "Roblox groups" };
  }
  return {
    found: true,
    inClan: true,
    clanName: rows[0].group && rows[0].group.name,
    extras: rows.slice(0, 4).map((r) => r.group && r.group.name).filter(Boolean),
    source: "Roblox groups",
  };
}

const LIVE = {
  albion: { label: "Albion Online" },
  roblox: { label: "Roblox" },
};

function canLiveCheck(gameId) {
  return Boolean(LIVE[gameId]);
}

function whyNoLive(gameId) {
  const reasons = {
    fortnite: "Fortnite has no public clan roster. Crew is a subscription, not a guild.",
    warframe: "Clan membership is only visible in-game. Sites do not publish it.",
    destiny2: "Needs a Bungie API key and the player's membership ID.",
    lol: "Clubs are not on OP.GG.",
    rocketleague: "Clubs need Epic auth, not a public name search.",
    clashofclans: "Needs a Supercell developer token.",
    clashroyale: "Needs a Supercell developer token.",
    brawlstars: "Needs a Supercell developer token.",
    ffxiv: "Lodestone has FC data, but the page blocks other sites from reading it.",
    wow: "Armory / Raider.IO need a realm + Blizzard/RIO access.",
    poe: "Public profiles exist; guild is not a stable public field.",
    osrs: "Hiscores are skills only. Clan is a separate, incomplete list.",
    eve: "Everyone is in a corporation. ESI name search is locked down.",
    destiny: "Needs Bungie OAuth.",
  };
  return reasons[gameId] || "This game does not publish clan membership to websites.";
}

async function liveMembership(gameId, ign, fetchFn) {
  const name = String(ign || "").trim();
  if (!name) return { ok: false, error: "Need an in-game name" };
  const get = fetchFn || fetch;
  try {
    if (gameId === "albion") {
      const res = await get(
        "https://gameinfo.albiononline.com/api/gameinfo/search?q=" + encodeURIComponent(name),
      );
      if (!res.ok) return { ok: false, error: "Albion API " + res.status };
      return { ok: true, ...parseAlbion(await res.json(), name) };
    }
    if (gameId === "roblox") {
      const res = await get(
        "https://users.roblox.com/v1/users/search?keyword=" + encodeURIComponent(name) + "&limit=10",
      );
      if (!res.ok) return { ok: false, error: "Roblox search " + res.status };
      const user = parseRobloxUser(await res.json(), name);
      if (!user) return { ok: true, found: false, inClan: false, source: "Roblox" };
      const gres = await get("https://groups.roblox.com/v2/users/" + user.id + "/groups/roles");
      if (!gres.ok) return { ok: false, error: "Roblox groups " + gres.status };
      return { ok: true, player: user.name, ...parseRobloxGroups(await gres.json()) };
    }
  } catch (err) {
    return {
      ok: false,
      error: "Browser blocked the live check (CORS). Open the public profile instead.",
    };
  }
  return { ok: false, error: whyNoLive(gameId) };
}

const membershipStore = {
  localMembership,
  parseAlbion,
  parseRobloxUser,
  parseRobloxGroups,
  canLiveCheck,
  whyNoLive,
  liveMembership,
};
if (typeof module !== "undefined" && module.exports) {
  module.exports = membershipStore;
}
if (typeof window !== "undefined") {
  window.ClanMembership = membershipStore;
}
